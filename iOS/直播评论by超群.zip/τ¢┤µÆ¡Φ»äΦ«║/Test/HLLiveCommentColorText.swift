//
//  ChatColorText.swift
//  Test
//
//  Created by 常超群的MacBookPro on 2021/8/5.
//

import UIKit

class HLLiveCommentColorText {
    private var colors = [
        UIColor(hexString: "#12B1F5")!
    ]
    private var colorIndex: Int = 0
    private var dicOfNameAndColor = [String: UIColor]()

    func colorText(nickName: String?, text: String?) -> NSAttributedString? {
        guard let nickName = nickName, let text = text else {return nil}
        let nickNameColor: UIColor = {
            if let color = dicOfNameAndColor[nickName] {
                return color
            }else {
                let color = colors[colorIndex]
                dicOfNameAndColor[nickName] = color
                colorIndex = (colorIndex + 1) % colors.count
                return color
            }
        }()
        let nickNameAttributedString = nickName.colored(with: nickNameColor)
        let textAttributedString = text.colored(with: .white)
        let mutt = NSMutableAttributedString()
        mutt.append(nickNameAttributedString)
        mutt.append(textAttributedString)
        let attributedString = NSAttributedString.init(attributedString: mutt)
        return attributedString
    }

}
