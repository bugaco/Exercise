//
//  HLLiveCommentCell.swift
//  Test
//
//  Created by 常超群的MacBookPro on 2021/8/5.
//

import UIKit

class HLLiveCommentCell: UITableViewCell {
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        self.selectionStyle = .none
        self.transform = CGAffineTransform(scaleX: 1, y: -1)
        loadUI()
        
    }
    lazy var titleLabel: UILabel = {
        let label = UILabel()
        label.textColor = .white
        label.font = .systemFont(ofSize: 15)
        label.numberOfLines = 0
        return label
    }()
    lazy var shareBtn: UIButton = {
        let btn = UIButton(type: .custom)
        btn.setTitle("我也要分享", for: .normal)
        btn.titleLabel?.font = .systemFont(ofSize: 12)
        btn.setTitleColor(UIColor(hexString: "#333333"), for: .normal)
        btn.contentEdgeInsets = UIEdgeInsets(top: 2, left: 5, bottom: 2, right: 5)
        btn.backgroundColor = UIColor(hexString: "#EEEEEE")
        btn.cornerRadius = 9
        return btn
    }()
    lazy var hStackView: UIStackView = {
        let stackView = UIStackView()
        stackView.axis = .horizontal
        stackView.spacing = 10
        stackView.alignment = .top
        return stackView
    }()
   
    lazy var bgView: UIView = {
        let view = UIView()
        view.backgroundColor = UIColor(hexString: "#333333")?.withAlphaComponent(0.5)
        view.cornerRadius = 14
        return view
    }()
    
    required init? (coder aDecoder: NSCoder) {
      super.init(coder: aDecoder)
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
    var attributedText: NSAttributedString? {
        didSet {
            updateUI()
        }
    }
}
// MARK: - 设置界面
extension HLLiveCommentCell {
    func loadUI() {
        
        contentView.addSubview(bgView)
        bgView.snp.makeConstraints { make in
            make.left.equalToSuperview().offset(10)
            make.top.equalToSuperview().offset(5)
            make.bottom.equalToSuperview().offset(-5)
            make.right.lessThanOrEqualToSuperview().offset(-40)
        }
        bgView.addSubview(hStackView)
        hStackView.snp.makeConstraints { make in
            make.edges.equalTo(UIEdgeInsets(top: 5, left: 12, bottom: 5, right: 12))
        }
        
        let titleBgView = setupRowBgView(with: hStackView)
        titleBgView.addSubview(titleLabel)
        titleLabel.snp.makeConstraints { make in
            make.edges.equalToSuperview()
        }
        
        let shareBgView = setupRowBgView(with: hStackView)
        shareBgView.addSubview(shareBtn)
        shareBtn.snp.makeConstraints { make in
            make.edges.equalToSuperview()
        }
    }
    
    ///设置每一行的bgView
    func setupRowBgView(with stackView: UIStackView) -> UIView {
        let view = UIView()
        stackView.addArrangedSubview(view)
        return view;
    }
}
// MARK: - 设置界面
extension HLLiveCommentCell {
    func updateUI() {
        titleLabel.attributedText = attributedText
    }
}
