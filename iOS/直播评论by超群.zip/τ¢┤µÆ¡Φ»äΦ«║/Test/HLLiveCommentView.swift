//
//  HLLiveCommentView.swift
//  Test
//
//  Created by 常超群的MacBookPro on 2021/8/5.
//

import UIKit
private enum CellType {
    /// 评论cell
    case comment
    /// 进入会议cell
    case enterMeeting
}
class HLLiveCommentView: UIView {
    override init(frame: CGRect) {
        super.init(frame: frame)
        loadUI()
    }
    func loadUI() {
        loadTableView()
    }
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    fileprivate var cellTypes: [CellType] = [.enterMeeting, .comment]
    private let maxMessageCount: Int = 500
    private var messages = [NSAttributedString]()
    private let maxEnterMeetingMessageCount: Int = 1
    private var enterMeetingmessages = [String]()
    let colorText = HLLiveCommentColorText()
    
    // 创建并发队列
    let concurrentQueue = DispatchQueue(label: "concurrentQueue", attributes: .concurrent)
    //初始化信号量为1
    let semaphore = DispatchSemaphore(value: 1)
    lazy var tableView: UITableView = {
        let tableView = UITableView(frame: CGRect.zero, style: .plain)
        tableView.tableFooterView = UIView()
        tableView.separatorStyle = .none
        tableView.dataSource = self
        tableView.delegate = self
        tableView.backgroundColor = .white
        tableView.transform = CGAffineTransform(scaleX: 1, y: -1)
        tableView.register(cellWithClass: HLLiveCommentCell.self)
        tableView.register(cellWithClass: HLLiveCommentEnterMeetingCell.self)
        return tableView
    }()
}
// MARK: - 设置界面
extension HLLiveCommentView: UITableViewDataSource, UITableViewDelegate {
    override func layoutSubviews() {
        super.layoutSubviews()
        tableView.separatorStyle = .none
    }
    func loadTableView() {
        self.addSubview(tableView)
        tableView.snp.makeConstraints { (make) in
            make.edges.equalToSuperview()
        }
    }
    func numberOfSections(in tableView: UITableView) -> Int {
        cellTypes.count
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        switch cellTypes[section] {
            case .enterMeeting:
                return enterMeetingmessages.count
            case .comment:
                return messages.count
        }
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        switch cellTypes[indexPath.section] {
            case .enterMeeting:
                let cell = self.tableView.dequeueReusableCell(withClass: HLLiveCommentEnterMeetingCell.self)
                cell.text = enterMeetingmessages[indexPath.row]
                return cell
            case .comment:
                let cell = self.tableView.dequeueReusableCell(withClass: HLLiveCommentCell.self)
                cell.attributedText = messages[indexPath.row]
                return cell
        }
    }
    ///写此方法可以让自动布局高度时候,系统快速计算高度, 可以不用写准确高度
    func tableView(_ tableView: UITableView, estimatedHeightForRowAt indexPath: IndexPath) -> CGFloat {
        44
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
    }
}

extension HLLiveCommentView {
    func addMsg(nickName:String, message: String) {
        guard let message = colorText.colorText(nickName: nickName, text: message) else { return }
        add(message: message)
    }
    private func add(message: NSAttributedString) {
        if let section = cellTypes.firstIndex(of: .comment) {
            messages.insert(message, at: 0)
            tableView.insertRows(at: [IndexPath.init(row: 0, section: section)], with: .top)
            if messages.count > maxMessageCount {
                messages.removeLast()
                self.tableView.deleteRows(at: [IndexPath.init(row: messages.count, section: section)], with: .none)
            }
        }
    }
    
    func addEnterMeetingMsg(nickName:String, message: String) {
        if let section = cellTypes.firstIndex(of: .enterMeeting) {
            // 队列操作, 悬停一秒
            concurrentQueue.async() {
                self.semaphore.wait()
                DispatchQueue.global().async {
                    DispatchQueue.main.async {
                        self.enterMeetingmessages.insert(nickName + message, at: 0)
                        self.tableView.insertRows(at: [IndexPath.init(row: 0, section: section)], with: .top)
                    }
                    sleep(1)
                    DispatchQueue.main.async {
                        self.enterMeetingmessages.removeLast()
                        self.tableView.deleteRows(at: [IndexPath.init(row: self.enterMeetingmessages.count, section: section)], with: .top)
                    }
                    self.semaphore.signal()
                }
            }
        }
    }
}
// MARK: - Action And Delagate

