//
//  ViewController.swift
//  Test
//
//  Created by 常超群的MacBookPro on 2021/8/5.
//

import UIKit
import SnapKit
import SwifterSwift
class ViewController: UIViewController {
    var index = 0
    var meetingIndex = 0
    override func viewDidLoad() {
        super.viewDidLoad()
        loadUI()
    }
    var liveCommentView = HLLiveCommentView()
    
    func loadUI() {
        loadLiveCommentView()
    }
}

// MARK: - 设置界面
extension ViewController {
    func loadLiveCommentView() {
        self.navigationItem.leftBarButtonItem = UIBarButtonItem(barButtonSystemItem: .add, target: self, action: #selector(addEnterMeetingMsg))
        self.navigationItem.rightBarButtonItem = UIBarButtonItem(barButtonSystemItem: .add, target: self, action: #selector(addMsg))
        self.view.addSubview(liveCommentView)
        liveCommentView.snp.makeConstraints { make in
            make.height.equalTo(UIScreen.main.bounds.size.height / 3)
            make.left.right.equalToSuperview()
            make.bottom.equalToSuperview().offset(-80)
        }
    }
}

extension ViewController {
    @objc func addMsg() {
        liveCommentView.addMsg(nickName: "小常：", message: "你吃饭了嘛\(index)嘛")
        index = index + 1
    }
    @objc func addEnterMeetingMsg() {
        liveCommentView.addEnterMeetingMsg(nickName: "小梅\(meetingIndex) ", message: "进入了会议")
        meetingIndex = meetingIndex + 1
    }
}
