/// Copyright (c) 2020 Razeware LLC
///
/// Permission is hereby granted, free of charge, to any person obtaining a copy
/// of this software and associated documentation files (the "Software"), to deal
/// in the Software without restriction, including without limitation the rights
/// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
/// copies of the Software, and to permit persons to whom the Software is
/// furnished to do so, subject to the following conditions:
///
/// The above copyright notice and this permission notice shall be included in
/// all copies or substantial portions of the Software.
///
/// Notwithstanding the foregoing, you may not use, copy, modify, merge, publish,
/// distribute, sublicense, create a derivative work, and/or sell copies of the
/// Software in any work that is designed, intended, or marketed for pedagogical or
/// instructional purposes related to programming, coding, application development,
/// or information technology.  Permission for such use, copying, modification,
/// merger, publication, distribution, sublicensing, creation of derivative works,
/// or sale is expressly withheld.
///
/// This project and source code may use libraries or frameworks that are
/// released under various Open-Source licenses. Use of those libraries and
/// frameworks are governed by their own individual licenses.
///
/// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
/// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
/// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
/// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
/// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
/// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
/// THE SOFTWARE.

import UIKit

///
/// Supporting Code for examples
///

struct OrderItem {
  var product: String
  var price: Decimal
  var quantity: Int
}


struct Order {
  var email: String
  var items: [OrderItem]
}

let orderItem = OrderItem(product: "Widget", price: 10.0, quantity: 3)
let orderItem2 = OrderItem(product: "Widget", price: 20.0, quantity: 4)

let order1 = Order(email: "test@example.com", items: [orderItem])
let order2 = Order(email: "other@example.com", items: [orderItem, orderItem2])
let orders = [order1, order2]

///
/// Better diagnostic error, non-SwiftUI example
/// Uncomment the code below to see the error
///

//let x: [Int] = [1, 2, 3]
//let w: UInt = 6
//
//let filtered = x.filter { ($0 + w) > 42 }

///
/// Callable values of user-defined nominal types (SE-0253)
///

struct Quadratic {
  var a: Double
  var b: Double
  var c: Double
  
  func callAsFunction(_ x: Double) -> Double {
    a * pow(x, 2) + b * x + c
  }
  
  func callAsFunction(_ xs: [Double]) -> [Double] {
    xs.map { callAsFunction($0) }
  }
  
  func calculate(_ x: Double) -> Double {
    a * pow(x, 2) + b * x + c
  }
}

let f = Quadratic(a: 4, b: 4, c: 3)
let y = f(5)
let z = f([5, 7, 9])

///
/// Key Path Expressions as Functions (SE-0249)
///

orders.map { $0.email }

orders.map(\.email)

/// This syntax is not allowed:
///
/// `let kp = \Order.email`
/// `orders.map(kp)`
///
/// But this one is allowed:

let asEmail: (Order) -> String = \Order.email
orders.map(asEmail)

///
/// Subscripts can now declare default arguments (SR-6118)
///

struct Multiplier {
  subscript(x: Int, y: Int = 1) -> Int {
    x * y
  }
}

let multiplier = Multiplier()

multiplier[2, 3]
multiplier[4]

///
/// When chaining calls to `filter(_:)` on a lazy sequence or collection, the filtering predicates
/// will now be called in the same order as eager filters (SR-11841)
///

let array = ["1", "2", "3"]
let filtered = array
  .filter { _ in
    print("A")
    return true
}
.filter { _ in
  print("B")
  return true
}

_ = Array(filtered)

let lazyFiltered = array.lazy
  .filter { _ in
    print("A")
    return true
}
.filter { _ in
  print("B")
  return true
}

_ = Array(lazyFiltered)

///
/// The compiler now supports local functions whose default arguments capture values from outer scopes (SR-2189)
///

func outer(x: Int) -> (Int, Int) {
  func inner(y: Int = x) -> Int {
    return y
  }
  
  return (inner(), inner(y: 0))
}

///
/// The compiler will now emit a warning when attempting to pass a temporary pointer argument produced
/// from an array, string, or inout argument to a parameter which is known to escape it (SR-2790)
///

func generatePointer() {
  var number: Int8 = 0
  let pointer = UnsafePointer(&number)
}

///
/// A method override is no longer allowed to have a generic signature with requirements not imposed by
/// the base method (SR-4206)
///

/// This code is no longer allowed:

//protocol P { }
//
//class Base {
//  func doWork<T>(input: T) { }
//}
//
//class Derived: Base {
//  override func doWork<T: P>(input: T) { }
//}

///
/// A class-constrained protocol extension will now infer the constraint implicitly (SR-11298)
///

protocol Foo { }

class Bar: Foo {
  var someProperty: Int = 0
}

extension Foo where Self: Bar {
  var anotherProperty: Int {
    get { return someProperty }
    set { someProperty = newValue }
  }
}

///
/// You can use the as operator to disambiguate a function with argument labels (SR-11429)
///

func print(x: Int) { print("Int \(x)") }
func print(x: UInt) { print("UInt \(x)") }

(print as (Int) -> Void)(5) // Prints Int 5
(print as (UInt) -> Void)(5) // Prints UInt 5

typealias Magic<T> = T
//(print as Magic)(x: 5) // Fails to compile
(print as Magic)(5)
