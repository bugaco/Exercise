package com.example.listviewtest

class Fruit(val name:String, val imageId: Int)