package com.example.activitytest

fun doSomething() {
    println("do something")
}